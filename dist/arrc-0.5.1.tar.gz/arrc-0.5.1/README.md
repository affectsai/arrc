~~~~# arrc

[![PyPI - Version](https://img.shields.io/pypi/v/arrc.svg)](https://pypi.org/project/arrc)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/arrc.svg)](https://pypi.org/project/arrc)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install arrc
```

## License

`arrc` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
